# maabe_telemetry (prototype)

A Rust prototype that implements the **cryptographic core** of the paper:

- BLAKE3-256 hashing
- Canonical encodings + Merkle aggregation
- AEAD (ChaCha20-Poly1305) with deterministic nonces
- HKDF-SHA256 KEK derivation + key-wrapping
- Bulletproofs (Ristretto255) aggregated 32-bit range proofs
- A practical **multi-authority ABE** instantiation using `rabe::schemes::aw11` (Lewko-Waters “Decentralizing ABE”)

Storage and chain are **simulated**:
- “IPFS raw block” is a local content-addressed object store using **CIDv1 (raw, sha2-256)**.
- “Blockchain” is an in-memory commit/finalize state machine that performs deterministic validator checks.

## Quick start

```bash
cargo test -q
cargo bench
```

The end-to-end test lives in `tests/e2e.rs`.
