use criterion::{criterion_group, criterion_main, Criterion, BatchSize};
use rand_core::OsRng;
use curve25519_dalek::scalar::Scalar;

use maabe_telemetry::types::*;
use maabe_telemetry::helpers::*;
use maabe_telemetry::chain_sim::rec_digest;
use maabe_telemetry::payload::RecordTuple;

fn bench_bulletproof_window(c: &mut Criterion) {
    // Parameter sweep inside Criterion so you get multiple datapoints.
    // For easy CSV graphs, prefer: `cargo run --release --bin bench_sweep -- ...`
    let ks: &[usize] = &[1, 2, 4, 8, 16];
    let ns: &[usize] = &[1, 2, 4, 8, 16, 32];

    let suite = ProofSuiteId(1);
    let schema = SchemaId(7);
    let pid = ProviderId([7u8; 32]);
    let wid = WindowId(1);
    let t0 = 1_700_000_000u64;

    let mut group = c.benchmark_group("bulletproof_window");
    group.sample_size(10);

    for &k in ks {
        let policy = Policy { bounds: vec![(0, u32::MAX); k] };
        let hpol = policy_hash(&policy);
        for &n_win in ns {
            group.bench_function(format!("prove+verify N={n_win} k={k}"), |b| {
                b.iter_batched(|| {
            // build commitments + witnesses
            let pc_gens = bulletproofs::PedersenGens::default();
            let mut records: Vec<RecordTuple> = Vec::new();
            let mut vals: Vec<u32> = Vec::new();
            let mut blinds: Vec<Scalar> = Vec::new();
            let mut commitments_flat = Vec::new();
            let mut seq = 1u64;
            for i in 0..n_win {
                let t = t0 + i as u64;
                let mut cvec = Vec::with_capacity(k);
                for j in 0..k {
                    let v = ((i * 17 + j) as u32) ^ 0xdeadbeefu32;
                    vals.push(v);
                    let r = Scalar::random(&mut OsRng);
                    blinds.push(r);
                    let cmt = pc_gens.commit(Scalar::from(v as u64), r).compress();
                    cvec.push(cmt);
                    commitments_flat.push(cmt);
                }
                let d = rec_digest(pid, wid, seq, t, schema, hpol, suite, &cvec);
                records.push(RecordTuple { d, seq, t, commitments: cvec, ciphertext: vec![] });
                seq += 1;
            }

            // minimal header bytes for transcript binding
            let root = [0u8; 32];
            let serhdr = header_bytes(pid, wid, 1, n_win as u64, root, t0, t0+n_win as u64-1, n_win as u64, schema, hpol, suite, 0, [0u8;32], b"cid");

                    (serhdr, commitments_flat, vals, blinds)
                }, |(serhdr, commitments_flat, vals, blinds)| {
                    let proof = maabe_telemetry::bulletproof_win::prove_window_ranges(&serhdr, hpol, &policy, &commitments_flat, &vals, &blinds).unwrap();
                    maabe_telemetry::bulletproof_win::verify_window_ranges(&serhdr, hpol, &policy, &commitments_flat, &proof).unwrap();
                }, BatchSize::SmallInput)
            });
        }
    }
    group.finish();
}

fn bench_aw11_abe(c: &mut Criterion) {
    use maabe_telemetry::abe_aw11::Aw11MaAbe;

    c.bench_function("aw11_maabe_encrypt+decrypt (2 auth, policy=A)", |b| {
        let abe = Aw11MaAbe::setup(2, &["A","B","C"]).unwrap();
        let user = abe.keygen_user("bob", &["A"]).unwrap();
        let mut msg = [0u8; 32];
        OsRng.fill_bytes(&mut msg);

        b.iter(|| {
            let ct = abe.encrypt(r#""A""#, &msg).unwrap();
            let pt = abe.decrypt(&user, &ct).unwrap();
            assert_eq!(pt, msg.to_vec());
        });
    });
}

criterion_group!(benches, bench_bulletproof_window, bench_aw11_abe);
criterion_main!(benches);
