use serde::{Deserialize, Serialize};

pub type Bytes32 = [u8; 32];

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct ProviderId(pub Bytes32);

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct WindowId(pub u64);

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct SchemaId(pub u32);

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, Serialize, Deserialize)]
pub struct ProofSuiteId(pub u32);

#[derive(Clone, Copy, Debug, PartialEq, Eq, Hash, Serialize, Deserialize, Default)]
pub struct ChainId(pub u32);

#[derive(Clone, Debug, Serialize, Deserialize)]
pub struct Policy {
    /// bounds[j] = (ell_j, u_j), both u32, inclusive.
    pub bounds: Vec<(u32, u32)>,
}

impl Policy {
    pub fn k(&self) -> usize { self.bounds.len() }
}
