use crate::helpers::transcript_seed;
use crate::types::{Bytes32, Policy};
use anyhow::{ensure, Result};
use bulletproofs::{BulletproofGens, PedersenGens, RangeProof};
use curve25519_dalek::ristretto::{CompressedRistretto, RistrettoPoint};
use curve25519_dalek::scalar::Scalar;
use merlin::Transcript;


/// Prover-side derived commitments+values+blindings, given original values+blindings and original commitments.
pub fn derive_commitments_prover(
    pc_gens: &PedersenGens,
    values_u32: &[u32],
    blindings: &[Scalar],
    commitments: &[CompressedRistretto],
    policy: &Policy,
) -> Result<(Vec<CompressedRistretto>, Vec<u64>, Vec<Scalar>)> {
    let k = policy.k();
    ensure!(values_u32.len() == blindings.len(), "values/blindings mismatch");
    ensure!(values_u32.len() == commitments.len(), "values/commitments mismatch");
    ensure!(values_u32.len() % k == 0, "values must be multiple of k");
    let nrec = values_u32.len() / k;

    let b = pc_gens.B;
    let mut out_comm = Vec::with_capacity(nrec * k * 2);
    let mut out_vals = Vec::with_capacity(nrec * k * 2);
    let mut out_blinds = Vec::with_capacity(nrec * k * 2);

    for i in 0..nrec {
        for j in 0..k {
            let idx = i*k + j;
            let (ell, u) = policy.bounds[j];
            let v = values_u32[idx] as i64;
            let ell_i = ell as i64;
            let u_i = u as i64;
            ensure!(v >= ell_i && v <= u_i, "value out of policy bounds");
            let v_lo = (v - ell_i) as u64;
            let v_hi = (u_i - v) as u64;

            let c: RistrettoPoint = commitments[idx].decompress().ok_or_else(|| anyhow::anyhow!("bad commitment encoding"))?;
            let c_lo = (c - (Scalar::from(ell as u64) * b)).compress();
            let c_hi = ((Scalar::from(u as u64) * b) - c).compress();

            out_comm.push(c_lo);
            out_vals.push(v_lo);
            out_blinds.push(blindings[idx]); // r

            out_comm.push(c_hi);
            out_vals.push(v_hi);
            out_blinds.push(-blindings[idx]); // -r
        }
    }
    Ok((out_comm, out_vals, out_blinds))
}

/// Verifier-side derived commitments list only (public).
pub fn derive_commitments_public(
    pc_gens: &PedersenGens,
    commitments: &[CompressedRistretto],
    policy: &Policy,
) -> Result<Vec<CompressedRistretto>> {
    let k = policy.k();
    ensure!(commitments.len() % k == 0, "commitments length must be multiple of k");
    let nrec = commitments.len() / k;

    let b = pc_gens.B;
    let mut out = Vec::with_capacity(nrec * k * 2);
    for i in 0..nrec {
        for j in 0..k {
            let idx = i*k + j;
            let (ell, u) = policy.bounds[j];
            let c: RistrettoPoint = commitments[idx].decompress().ok_or_else(|| anyhow::anyhow!("bad commitment encoding"))?;
            out.push((c - (Scalar::from(ell as u64) * b)).compress());
            out.push(((Scalar::from(u as u64) * b) - c).compress());
        }
    }
    Ok(out)
}

fn pad_to_pow2<T: Clone>(mut v: Vec<T>, pad: T) -> Vec<T> {
    let mut n = v.len();
    let target = n.next_power_of_two();
    while n < target {
        v.push(pad.clone());
        n += 1;
    }
    v
}

pub fn prove_window_ranges(
    serhdr: &[u8],
    hpol: Bytes32,
    policy: &Policy,
    commitments: &[CompressedRistretto], // original commitments in payload order
    values_u32: &[u32],                 // original values in same order
    blindings: &[Scalar],               // original blindings in same order
) -> Result<Vec<u8>> {
    let pc_gens = PedersenGens::default();

    let (derived_comm, derived_vals, derived_blinds) =
        derive_commitments_prover(&pc_gens, values_u32, blindings, commitments, policy)?;

    // Bulletproofs requires m to be power-of-two. We pad deterministically with commitment to 0 using blinding 0.
    let pad_commit = CompressedRistretto::default(); // identity point
    let pad_scalar = Scalar::ZERO;
    let derived_comm = pad_to_pow2(derived_comm, pad_commit);
    let derived_vals = pad_to_pow2(derived_vals, 0u64);
    let derived_blinds = pad_to_pow2(derived_blinds, pad_scalar);

    let m = derived_vals.len();
    let bp_gens = BulletproofGens::new(32, m);
    let hdr_pre = crate::helpers::header_pre_hash(serhdr);
    let tr_seed = transcript_seed(hdr_pre, hpol);

    let mut transcript = Transcript::new(b"maabe:bp:range:v2");
    transcript.append_message(b"trSeed", &tr_seed);

    let (proof, commitments_out) = RangeProof::prove_multiple(
        &bp_gens,
        &pc_gens,
        &mut transcript,
        &derived_vals,
        &derived_blinds,
        32,
    )?;

    // Sanity: returned commitments match our derived commitments (after padding)
    ensure!(commitments_out.len() == derived_comm.len(), "commitment count mismatch");
    for (a, b) in commitments_out.iter().zip(derived_comm.iter()) {
        ensure!(a.as_bytes() == b.as_bytes(), "derived commitment mismatch");
    }

    Ok(proof.to_bytes())
}

pub fn verify_window_ranges(
    serhdr: &[u8],
    hpol: Bytes32,
    policy: &Policy,
    commitments: &[CompressedRistretto], // original commitments in payload order
    proof_bytes: &[u8],
) -> Result<()> {
    let pc_gens = PedersenGens::default();
    let mut derived_comm = derive_commitments_public(&pc_gens, commitments, policy)?;

    // Deterministic padding to power-of-two with identity points
    derived_comm = pad_to_pow2(derived_comm, CompressedRistretto::default());
    let m = derived_comm.len();
    let bp_gens = BulletproofGens::new(32, m);

    let hdr_pre = crate::helpers::header_pre_hash(serhdr);
    let tr_seed = transcript_seed(hdr_pre, hpol);

    let mut transcript = Transcript::new(b"maabe:bp:range:v2");
    transcript.append_message(b"trSeed", &tr_seed);

    let proof = RangeProof::from_bytes(proof_bytes)?;
    proof.verify_multiple(&bp_gens, &pc_gens, &mut transcript, &derived_comm, 32)?;
    Ok(())
}
