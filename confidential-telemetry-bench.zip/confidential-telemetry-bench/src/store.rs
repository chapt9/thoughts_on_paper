use anyhow::{ensure, Result};
use cid::Cid;
use multihash_codetable::{Code, MultihashDigest};
use std::fs;
use std::path::{Path, PathBuf};

pub const RAW_CODEC: u64 = 0x55; // multicodec 'raw'

#[derive(Clone, Debug)]
pub struct LocalIpfsStore {
    root: PathBuf,
}

impl LocalIpfsStore {
    pub fn new(root: impl AsRef<Path>) -> Result<Self> {
        let root = root.as_ref().to_path_buf();
        fs::create_dir_all(&root)?;
        Ok(Self { root })
    }

    pub fn put_raw_block(&self, bytes: &[u8]) -> Result<Cid> {
        let mh = Code::Sha2_256.digest(bytes); // multihash sha2-256
        let cid = Cid::new_v1(RAW_CODEC, mh);
        let p = self.root.join(cid.to_string());
        fs::write(p, bytes)?;
        Ok(cid)
    }

    pub fn get(&self, cid: &Cid) -> Result<Vec<u8>> {
        self.enforce_cid_constraints(cid)?;
        let p = self.root.join(cid.to_string());
        let bytes = fs::read(p)?;
        Ok(bytes)
    }

    pub fn enforce_cid_constraints(&self, cid: &Cid) -> Result<()> {
        ensure!(cid.version() == cid::Version::V1, "CID must be v1");
        ensure!(cid.codec() == RAW_CODEC, "CID codec must be raw (0x55)");
        // sha2-256 multihash code is 0x12 (per multihash table)
        ensure!(cid.hash().code() == 0x12, "CID multihash must be sha2-256");
        Ok(())
    }
}
