use crate::types::{Bytes32, ProviderId, WindowId, SchemaId, ProofSuiteId, Policy, ChainId};
use anyhow::{ensure, Result};
use blake3::Hasher;

pub const DS_LEAF: &str = "maabe:leaf:v2";
pub const DS_NODE: &str = "maabe:node:v2";
pub const DS_ZERO: &str = "maabe:merkle:zero:v2";
pub const DS_POLICY: &str = "maabe:policy:v2";
pub const DS_ATTEST: &str = "maabe:attest:v2";
pub const DS_HDRPRE: &str = "maabe:hdrpre:v2";
pub const DS_TRANSCRIPT: &str = "maabe:bp:transcript:v2";

pub fn hb(data: &[u8]) -> Bytes32 {
    let mut out = [0u8; 32];
    out.copy_from_slice(blake3::hash(data).as_bytes());
    out
}

pub fn hb_ds(ds: &str, body: &[u8]) -> Bytes32 {
    let mut h = Hasher::new();
    h.update(ds.as_bytes());
    h.update(body);
    let mut out = [0u8; 32];
    out.copy_from_slice(h.finalize().as_bytes());
    out
}

pub fn enc_u32(x: u32) -> [u8; 4] { x.to_be_bytes() }
pub fn enc_u64(x: u64) -> [u8; 8] { x.to_be_bytes() }

pub fn i2osp_u128(x: u128, len: usize) -> Result<Vec<u8>> {
    // big-endian fixed length.
    let mut buf = vec![0u8; len];
    let mut v = x;
    for i in 0..len {
        let idx = len - 1 - i;
        buf[idx] = (v & 0xff) as u8;
        v >>= 8;
    }
    ensure!(v == 0, "i2osp overflow for len={}", len);
    Ok(buf)
}

pub fn policy_hash(theta: &Policy) -> Bytes32 {
    // Canonical: (k=u64) then for each j: ell(u32) || u(u32)
    let mut b = Vec::with_capacity(8 + theta.bounds.len() * 8);
    b.extend_from_slice(&enc_u64(theta.bounds.len() as u64));
    for (ell, u) in theta.bounds.iter() {
        b.extend_from_slice(&enc_u32(*ell));
        b.extend_from_slice(&enc_u32(*u));
    }
    hb_ds(DS_POLICY, &b)
}

pub fn aad_bytes(pid: ProviderId, wid: WindowId, seq: u64, t: u64, schema: SchemaId, hpol: Bytes32, suite: ProofSuiteId) -> Vec<u8> {
    let mut aad = Vec::with_capacity(32 + 8 + 8 + 8 + 4 + 32 + 4);
    aad.extend_from_slice(&pid.0);
    aad.extend_from_slice(&enc_u64(wid.0));
    aad.extend_from_slice(&enc_u64(seq));
    aad.extend_from_slice(&enc_u64(t));
    aad.extend_from_slice(&enc_u32(schema.0));
    aad.extend_from_slice(&hpol);
    aad.extend_from_slice(&enc_u32(suite.0));
    aad
}

pub fn header_bytes(
    pid: ProviderId,
    wid: WindowId,
    seq_min: u64,
    seq_max: u64,
    merkle_root: Bytes32,
    t_min: u64,
    t_max: u64,
    n_win: u64,
    schema: SchemaId,
    hpol: Bytes32,
    suite: ProofSuiteId,
    payload_len: u64,
    payload_digest: Bytes32,
    cid_rec: &[u8],
) -> Vec<u8> {
    let mut b = Vec::with_capacity(32 + 8*6 + 32 + 4 + 32 + 4 + 8 + 32 + 8 + cid_rec.len());
    b.extend_from_slice(&pid.0);
    b.extend_from_slice(&enc_u64(wid.0));
    b.extend_from_slice(&enc_u64(seq_min));
    b.extend_from_slice(&enc_u64(seq_max));
    b.extend_from_slice(&merkle_root);
    b.extend_from_slice(&enc_u64(t_min));
    b.extend_from_slice(&enc_u64(t_max));
    b.extend_from_slice(&enc_u64(n_win));
    b.extend_from_slice(&enc_u32(schema.0));
    b.extend_from_slice(&hpol);
    b.extend_from_slice(&enc_u32(suite.0));
    b.extend_from_slice(&enc_u64(payload_len));
    b.extend_from_slice(&payload_digest);
    b.extend_from_slice(&enc_u64(cid_rec.len() as u64));
    b.extend_from_slice(cid_rec);
    b
}

pub fn header_pre_hash(serhdr: &[u8]) -> Bytes32 {
    hb_ds(DS_HDRPRE, serhdr)
}

pub fn attest_hash(serhdr: &[u8], chain_id: ChainId, h_accept: u64) -> Bytes32 {
    let mut b = Vec::with_capacity(4 + 8 + serhdr.len());
    b.extend_from_slice(&enc_u32(chain_id.0));
    b.extend_from_slice(&enc_u64(h_accept));
    b.extend_from_slice(serhdr);
    hb_ds(DS_ATTEST, &b)
}

pub fn transcript_seed(hdr_pre: Bytes32, hpol: Bytes32) -> Bytes32 {
    let mut b = Vec::with_capacity(32 + 32);
    b.extend_from_slice(&hdr_pre);
    b.extend_from_slice(&hpol);
    hb_ds(DS_TRANSCRIPT, &b)
}

pub fn nonce_from_index(win_index: u128) -> Result<[u8; 12]> {
    let v = i2osp_u128(win_index, 12)?;
    let mut out = [0u8; 12];
    out.copy_from_slice(&v);
    Ok(out)
}

pub fn version_tag_payload_v2() -> [u8; 32] {
    // "MAABE-PAYLOAD-V2" || 0x00*16, as in the paper
    let mut tag = [0u8; 32];
    let s = b"MAABE-PAYLOAD-V2";
    tag[..s.len()].copy_from_slice(s);
    tag
}
