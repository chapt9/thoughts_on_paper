use anyhow::{ensure, Result};

/// Deployment-fixed parameters shared by providers and validators.
///
/// Paper alignment:
/// - N_win_max is fixed per deployment.
/// - Merkle depth D = ceil(log2(N_win_max)) is fixed per deployment.
/// - L_max bounds payload size (application-level).
#[derive(Clone, Debug)]
pub struct ProtocolParams {
    pub n_win_max: usize,
    pub merkle_depth: usize,
    pub l_max: u64,
}

impl Default for ProtocolParams {
    fn default() -> Self {
        // Safe, paper-aligned defaults for tests/benches.
        // Deployments should override these via CLI/config.
        let n_win_max = 1024usize;
        // depth D = ceil(log2(N_win_max))
        let np2 = (n_win_max as u64).next_power_of_two();
        let merkle_depth = np2.trailing_zeros() as usize;
        let l_max = 16 * 1024 * 1024; // 16 MiB
        Self { n_win_max, merkle_depth, l_max }
    }
}

impl ProtocolParams {
    /// Create deployment parameters.
    ///
    /// `merkle_depth` is computed as ceil(log2(n_win_max)) i.e. log2(next_power_of_two(n_win_max)).
    pub fn new(n_win_max: usize, l_max: u64) -> Result<Self> {
        ensure!(n_win_max > 0, "N_win_max must be > 0");
        // depth D = ceil(log2(N_win_max))
        let np2 = (n_win_max as u64).next_power_of_two();
        let merkle_depth = np2.trailing_zeros() as usize;
        Ok(Self { n_win_max, merkle_depth, l_max })
    }

    pub fn ensure_n_win(&self, n_win: usize) -> Result<()> {
        ensure!(n_win > 0, "N_win must be > 0");
        ensure!(n_win <= self.n_win_max, "N_win exceeds deployment N_win_max");
        Ok(())
    }
}
