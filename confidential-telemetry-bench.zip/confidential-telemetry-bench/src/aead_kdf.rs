use crate::helpers::{enc_u64, hb};
use crate::types::{Bytes32, ProviderId, WindowId};
use anyhow::{ensure, Result};
use chacha20poly1305::{ChaCha20Poly1305, Key, Nonce};
use chacha20poly1305::aead::{Aead, KeyInit, Payload};
use hkdf::Hkdf;
use sha2::Sha256;

pub fn aead_encrypt(key32: &Bytes32, nonce12: &[u8; 12], aad: &[u8], plaintext: &[u8]) -> Result<Vec<u8>> {
    let cipher = ChaCha20Poly1305::new(Key::from_slice(key32));
    let ct = cipher.encrypt(Nonce::from_slice(nonce12), Payload { msg: plaintext, aad })
        .map_err(|e| anyhow::anyhow!("aead encrypt failed: {:?}", e))?;
    Ok(ct)
}

pub fn aead_decrypt(key32: &Bytes32, nonce12: &[u8; 12], aad: &[u8], ciphertext: &[u8]) -> Result<Vec<u8>> {
    let cipher = ChaCha20Poly1305::new(Key::from_slice(key32));
    let pt = cipher.decrypt(Nonce::from_slice(nonce12), Payload { msg: ciphertext, aad })
        .map_err(|e| anyhow::anyhow!("aead decrypt failed: {:?}", e))?;
    Ok(pt)
}

/// Derive the per-window KEK.
///
/// Paper alignment (Algorithm A.1):
///   salt = Hb("maabe-streaming:win-key")
///   info = "win-key" || enc32(pid) || enc8(wid) || H_att
pub fn derive_kek(z: &[u8], pid: ProviderId, wid: WindowId, hatt: &Bytes32) -> Result<Bytes32> {
    // salt = Hb("maabe-streaming:win-key")
    let salt = hb(b"maabe-streaming:win-key");
    let mut info = Vec::with_capacity(7 + 32 + 8 + 32);
    info.extend_from_slice(b"win-key");
    info.extend_from_slice(&pid.0);
    info.extend_from_slice(&enc_u64(wid.0));
    info.extend_from_slice(hatt);

    let hk = Hkdf::<Sha256>::new(Some(&salt), z);
    let mut okm = [0u8; 32];
    hk.expand(&info, &mut okm).map_err(|_| anyhow::anyhow!("hkdf expand failed"))?;
    Ok(okm)
}

/// Wrap a 32-byte AEAD key K under KEK with implicit nonce=0^12 and aad = enc32(Hpol)||Hatt.
pub fn wrap_window_key(kek: &Bytes32, hpol: &Bytes32, hatt: &Bytes32, k: &Bytes32) -> Result<Vec<u8>> {
    let mut aad = Vec::with_capacity(4 + 32 + 32);
    // paper uses enc32(Hpol) where Hpol is 32 bytes (pass-through); our enc_u32 is for u32, so just append bytes.
    aad.extend_from_slice(hpol);
    aad.extend_from_slice(hatt);
    let nonce = [0u8; 12];
    aead_encrypt(kek, &nonce, &aad, k)
}

pub fn unwrap_window_key(kek: &Bytes32, hpol: &Bytes32, hatt: &Bytes32, ct_k: &[u8]) -> Result<Bytes32> {
    let mut aad = Vec::with_capacity(64);
    aad.extend_from_slice(hpol);
    aad.extend_from_slice(hatt);
    let nonce = [0u8; 12];
    let pt = aead_decrypt(kek, &nonce, &aad, ct_k)?;
    ensure!(pt.len() == 32, "K must decode to 32 bytes");
    let mut k = [0u8; 32];
    k.copy_from_slice(&pt);
    Ok(k)
}
