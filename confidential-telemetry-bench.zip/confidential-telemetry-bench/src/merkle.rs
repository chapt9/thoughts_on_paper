use crate::helpers::{hb_ds, DS_NODE, DS_ZERO};
use crate::types::Bytes32;
use anyhow::{ensure, Result};

pub fn node_hash(left: Bytes32, right: Bytes32) -> Bytes32 {
    let mut b = Vec::with_capacity(32 + 32);
    b.extend_from_slice(&left);
    b.extend_from_slice(&right);
    hb_ds(DS_NODE, &b)
}

pub fn default_nodes(depth: usize) -> Vec<Bytes32> {
    // Z0 = Hb(DS_ZERO || 0x00), Z_{l+1} = NodeHash(Z_l, Z_l)
    let z0 = hb_ds(DS_ZERO, &[0u8]);
    let mut zs = Vec::with_capacity(depth + 1);
    zs.push(z0);
    for i in 0..depth {
        let prev = zs[i];
        zs.push(node_hash(prev, prev));
    }
    zs
}

/// Aggregate leaves into a root with canonical defaults.
/// - indices are leaf indices in [0, 2^D)
pub fn merkle_aggregate(depth: usize, leaves_sparse: &[(u64, Bytes32)]) -> Result<Bytes32> {
    let size = 1usize.checked_shl(depth as u32).ok_or_else(|| anyhow::anyhow!("depth too large"))?;
    let defaults = default_nodes(depth);
    let mut leaf = vec![defaults[0]; size];

    for (idx, d) in leaves_sparse.iter() {
        ensure!((*idx as usize) < size, "leaf index out of range");
        leaf[*idx as usize] = *d;
    }

    let mut level = leaf;
    for _ in 0..depth {
        let mut next = Vec::with_capacity(level.len() / 2);
        for j in 0..(level.len() / 2) {
            next.push(node_hash(level[2*j], level[2*j + 1]));
        }
        level = next;
    }
    ensure!(level.len() == 1, "bad merkle reduction");
    Ok(level[0])
}
