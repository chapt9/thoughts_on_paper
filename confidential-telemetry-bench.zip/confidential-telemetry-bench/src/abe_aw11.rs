use anyhow::{anyhow, Result};
use rabe::schemes::aw11;
use rabe::utils::policy::pest::PolicyLanguage;

fn rabe_to_anyhow(e: rabe::error::RabeError) -> anyhow::Error {
    // rabe::error::RabeError does not implement std::error::Error in some versions,
    // so we convert it explicitly.
    anyhow!(format!("{e:?}"))
}

/// A practical MA-ABE instantiation using Lewko-Waters AW11 ("Decentralizing ABE").
///
/// Notes:
/// - This is **multi-authority**, but it is not the Chase 2007 scheme.
/// - It is an operationally useful stand-in for benchmarking and integration testing.
/// - If you need Chase-style MA-ABE exactly, you will likely need a custom implementation.
pub struct Aw11MaAbe {
    pub gk: aw11::Aw11GlobalKey,
    pub pks: Vec<aw11::Aw11PublicKey>,
    pub msks: Vec<aw11::Aw11MasterKey>,
}

impl Aw11MaAbe {
    /// Create `n_auth` authorities. Each authority is initialized with the same attribute universe for simplicity.
    pub fn setup(n_auth: usize, attributes: &[&str]) -> Result<Self> {
        let gk = aw11::setup();
        let mut pks = Vec::with_capacity(n_auth);
        let mut msks = Vec::with_capacity(n_auth);
        for _ in 0..n_auth {
            let (pk, msk) = aw11::authgen(&gk, &attributes.to_vec())
                .ok_or_else(|| anyhow!("aw11::authgen returned None"))?;
            pks.push(pk);
            msks.push(msk);
        }
        Ok(Self { gk, pks, msks })
    }

    /// Keygen for a user with a set of attributes (the demo uses 1 authority for keygen).
    pub fn keygen_user(&self, user: &str, attrs: &[&str]) -> Result<aw11::Aw11SecretKey> {
        // In AW11, keygen is performed against an authority master key.
        // For benchmarking, we use authority 0.
        let sk = aw11::keygen(&self.gk, &self.msks[0], &user.to_string(), &attrs.to_vec())
            .map_err(rabe_to_anyhow)?;
        Ok(sk)
    }

    pub fn encrypt(&self, policy: &str, plaintext: &[u8]) -> Result<aw11::Aw11Ciphertext> {
        let refs: Vec<&aw11::Aw11PublicKey> = self.pks.iter().collect();
        let ct = aw11::encrypt(
            &self.gk,
            &refs,
            &policy.to_string(),
            PolicyLanguage::HumanPolicy,
            plaintext,
        )
        .map_err(rabe_to_anyhow)?;
        Ok(ct)
    }

    pub fn decrypt(&self, sk: &aw11::Aw11SecretKey, ct: &aw11::Aw11Ciphertext) -> Result<Vec<u8>> {
        let pt = aw11::decrypt(&self.gk, sk, ct).map_err(rabe_to_anyhow)?;
        Ok(pt)
    }
}
