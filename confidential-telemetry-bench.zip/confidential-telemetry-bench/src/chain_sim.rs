use crate::helpers::*;
use crate::merkle::merkle_aggregate;
use crate::payload::RecordTuple;
use crate::store::LocalIpfsStore;
use crate::types::*;
use crate::params::ProtocolParams;
use anyhow::{ensure, Result};
use cid::Cid;
use curve25519_dalek::ristretto::CompressedRistretto;

#[derive(Clone, Debug)]
pub struct AcceptedWindow {
    pub serhdr: Vec<u8>,
    pub hatt: Bytes32,
    pub h_accept: u64,
    pub cid_rec: Cid,
    pub cid_proof: Cid,
}

#[derive(Clone, Debug)]
pub struct PendingCommit {
    pub serhdr: Vec<u8>,
    pub cid_rec: Cid,
    pub payload_len: u64,
    pub payload_digest: Bytes32,
    pub merkle_root: Bytes32,
    pub n_win: u64,
    pub schema: SchemaId,
    pub hpol: Bytes32,
    pub suite: ProofSuiteId,
    pub wid: WindowId,
    pub pid: ProviderId,
    pub seq_min: u64,
    pub seq_max: u64,
    pub t_min: u64,
    pub t_max: u64,
}

#[derive(Default)]
pub struct ChainSim {
    pub chain_id: ChainId,
    pub height: u64,
    pub params: ProtocolParams,
    pub pending: Option<PendingCommit>,
    pub accepted: Option<AcceptedWindow>,
}

impl ChainSim {
    pub fn new(chain_id: u32, params: ProtocolParams) -> Self {
        Self { chain_id: ChainId(chain_id), height: 0, params, pending: None, accepted: None }
    }

    pub fn commit_window(&mut self, pc: PendingCommit) -> Result<()> {
        ensure!(self.pending.is_none(), "already have pending commit");
        // basic contract checks (more can be added)
        ensure!(pc.n_win > 0, "N_win must be > 0");
        self.params.ensure_n_win(pc.n_win as usize)?;
        ensure!(pc.payload_len <= self.params.l_max, "payload L exceeds L_max");
        self.pending = Some(pc);
        Ok(())
    }

    pub fn finalize_window(
        &mut self,
        store: &LocalIpfsStore,
        policy: &Policy,
        proof_bytes: &[u8],
        cid_proof: Cid,
    ) -> Result<AcceptedWindow> {
        let pc = self.pending.take().ok_or_else(|| anyhow::anyhow!("no pending commit"))?;

        // fetch payload and validate digest/size
        let b_rec = store.get(&pc.cid_rec)?;
        ensure!(b_rec.len() as u64 == pc.payload_len, "payload len mismatch");
        ensure!(hb(&b_rec) == pc.payload_digest, "payload digest mismatch");

        // parse payload and recompute digests/root
        let (records, flat_commitments) = parse_payload(&b_rec, pc.n_win as usize, policy.k())?;

        // Header/payload sequencing bounds checks (paper: deterministic validator logic)
        ensure!(records.first().unwrap().seq == pc.seq_min, "seq_min mismatch");
        ensure!(records.last().unwrap().seq == pc.seq_max, "seq_max mismatch");
        let t_min = records.iter().map(|r| r.t).min().unwrap();
        let t_max = records.iter().map(|r| r.t).max().unwrap();
        ensure!(t_min == pc.t_min, "t_min mismatch");
        ensure!(t_max == pc.t_max, "t_max mismatch");
        // recompute d_i' and check
        for (i, r) in records.iter().enumerate() {
            let offs = i*policy.k();
            let d2 = rec_digest(
                pc.pid, pc.wid, r.seq, r.t, pc.schema, pc.hpol, pc.suite,
                &flat_commitments[offs..offs+policy.k()],
            );
            ensure!(d2 == r.d, "record digest mismatch at i={}", i);
        }
        // merkle aggregate root
        // Paper alignment: Merkle depth is deployment-fixed (derived from N_win_max), not per-window.
        let depth = self.params.merkle_depth;
        let leaves: Vec<(u64, Bytes32)> = records.iter().enumerate().map(|(i,r)| (i as u64, r.d)).collect();
        let r2 = merkle_aggregate(depth, &leaves)?;
        ensure!(r2 == pc.merkle_root, "merkle root mismatch");

        // verify bulletproof range proof
        crate::bulletproof_win::verify_window_ranges(&pc.serhdr, pc.hpol, policy, &flat_commitments, proof_bytes)?;

        // accept
        self.height += 1;
        let h_accept = self.height;
        let hatt = attest_hash(&pc.serhdr, self.chain_id, h_accept);
        let aw = AcceptedWindow {
            serhdr: pc.serhdr,
            hatt,
            h_accept,
            cid_rec: pc.cid_rec,
            cid_proof,
        };
        self.accepted = Some(aw.clone());
        Ok(aw)
    }
}

/// Deterministic record digest function (public)
pub fn rec_digest(
    pid: ProviderId,
    wid: WindowId,
    seq: u64,
    t: u64,
    schema: SchemaId,
    hpol: Bytes32,
    suite: ProofSuiteId,
    commitments: &[CompressedRistretto],
) -> Bytes32 {
    let mut b = Vec::with_capacity(32 + 8 + 8 + 8 + 4 + 32 + 4 + commitments.len()*32);
    b.extend_from_slice(&pid.0);
    b.extend_from_slice(&enc_u64(wid.0));
    b.extend_from_slice(&enc_u64(seq));
    b.extend_from_slice(&enc_u64(t));
    b.extend_from_slice(&enc_u32(schema.0));
    b.extend_from_slice(&hpol);
    b.extend_from_slice(&enc_u32(suite.0));
    for c in commitments {
        b.extend_from_slice(c.as_bytes());
    }
    hb_ds(DS_LEAF, &b)
}

/// Minimal payload parser matching build_payload() in payload.rs.
pub fn parse_payload(
    bytes: &[u8],
    n_win: usize,
    k: usize,
) -> Result<(Vec<RecordTuple>, Vec<CompressedRistretto>)> {
    use crate::helpers::version_tag_payload_v2;

    let mut off = 0usize;
    let tag = version_tag_payload_v2();
    ensure!(bytes.len() >= 32, "payload too short");
    ensure!(&bytes[..32] == &tag, "bad version tag");
    off += 32;

    let n_payload = u64::from_be_bytes(bytes[off..off+8].try_into().unwrap()) as usize;
    off += 8;
    ensure!(n_payload == n_win, "N_win mismatch (payload vs header)");

    let mut recs = Vec::with_capacity(n_win);
    let mut flat_commit = Vec::with_capacity(n_win * k);
    let mut prev_seq: Option<u64> = None;

    for _i in 0..n_win {
        ensure!(off + 32 + 8 + 8 <= bytes.len(), "truncated");
        let mut d = [0u8; 32];
        d.copy_from_slice(&bytes[off..off+32]); off += 32;
        let seq = u64::from_be_bytes(bytes[off..off+8].try_into().unwrap()); off += 8;
        let t = u64::from_be_bytes(bytes[off..off+8].try_into().unwrap()); off += 8;

        // Paper alignment: canonical payload requires strictly increasing seq.
        if let Some(p) = prev_seq {
            ensure!(seq > p, "seq must be strictly increasing");
        }
        prev_seq = Some(seq);

        let c_len = u64::from_be_bytes(bytes[off..off+8].try_into().unwrap()) as usize; off += 8;
        ensure!(off + c_len <= bytes.len(), "truncated C");
        ensure!(c_len == k*32, "C length mismatch");
        let cbytes = &bytes[off..off+c_len]; off += c_len;
        let mut commitments = Vec::with_capacity(k);
        for j in 0..k {
            let b32: [u8; 32] = cbytes[j*32..(j+1)*32].try_into().unwrap();
            let c = CompressedRistretto::from_slice(&b32).map_err(|e| anyhow::anyhow!(e))?;
            commitments.push(c);
            flat_commit.push(c);
        }

        let p_len = u64::from_be_bytes(bytes[off..off+8].try_into().unwrap()) as usize; off += 8;
        ensure!(off + p_len <= bytes.len(), "truncated P");
        let ciphertext = bytes[off..off+p_len].to_vec(); off += p_len;

        recs.push(RecordTuple { d, seq, t, commitments, ciphertext });
    }

    ensure!(off == bytes.len(), "trailing bytes not allowed");
    Ok((recs, flat_commit))
}
