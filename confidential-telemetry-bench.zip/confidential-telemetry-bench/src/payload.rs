use crate::helpers::{enc_u64, version_tag_payload_v2, hb};
use crate::types::Bytes32;
use anyhow::{ensure, Result};
use curve25519_dalek::ristretto::CompressedRistretto;

#[derive(Clone, Debug)]
pub struct RecordTuple {
    pub d: Bytes32,
    pub seq: u64,
    pub t: u64,
    /// k commitments, already encoded (32 bytes each)
    pub commitments: Vec<CompressedRistretto>,
    pub ciphertext: Vec<u8>,
}

/// Canonical payload bytes B_rec, exactly matching Algorithm A.1 in the paper.
/// Constraints:
/// - seq strictly increasing
/// - n_win > 0
/// - commitments.len() == k for all records (deployment fixed)
pub fn build_payload(records: &[RecordTuple], k: usize) -> Result<(Vec<u8>, u64, Bytes32)> {
    ensure!(!records.is_empty(), "N_win must be > 0");
    for i in 1..records.len() {
        ensure!(records[i-1].seq < records[i].seq, "seq must be strictly increasing");
    }
    for r in records {
        ensure!(r.commitments.len() == k, "commitments length must equal k");
    }

    let mut b = Vec::new();
    b.extend_from_slice(&version_tag_payload_v2());
    b.extend_from_slice(&enc_u64(records.len() as u64));

    for r in records {
        b.extend_from_slice(&r.d);
        b.extend_from_slice(&enc_u64(r.seq));
        b.extend_from_slice(&enc_u64(r.t));

        // C_i bytes
        let mut cbytes = Vec::with_capacity(k * 32);
        for c in r.commitments.iter() {
            cbytes.extend_from_slice(c.as_bytes());
        }
        b.extend_from_slice(&enc_u64(cbytes.len() as u64));
        b.extend_from_slice(&cbytes);

        // P_i bytes
        b.extend_from_slice(&enc_u64(r.ciphertext.len() as u64));
        b.extend_from_slice(&r.ciphertext);
    }

    let l = b.len() as u64;
    let h_batch = hb(&b);
    Ok((b, l, h_batch))
}
