use anyhow::Result;
use curve25519_dalek::scalar::Scalar;
use rand_core::{OsRng, RngCore};

use maabe_telemetry::types::*;
use maabe_telemetry::helpers::*;
use maabe_telemetry::chain_sim::{rec_digest, PendingCommit};
use maabe_telemetry::payload::RecordTuple;
use maabe_telemetry::store::LocalIpfsStore;
use maabe_telemetry::aead_kdf::*;
use maabe_telemetry::abe_aw11::Aw11MaAbe;
use maabe_telemetry::params::ProtocolParams;

#[test]
fn end_to_end_window() -> Result<()> {
    // --- deployment constants
    let k = 4usize;
    let policy = Policy { bounds: vec![(0, u32::MAX); k] };
    let hpol = policy_hash(&policy);
    let suite = ProofSuiteId(1);
    let schema = SchemaId(7);

    let pid = ProviderId([7u8; 32]);
    let wid = WindowId(1);

    // --- simulate per-window secrets
    let mut rng = OsRng;
    let mut z = [0u8; 32];
    rng.fill_bytes(&mut z);
    let mut k_aead = [0u8; 32];
    rng.fill_bytes(&mut k_aead);

    // --- create ABE authorities and user
    let abe = Aw11MaAbe::setup(2, &["A","B","C"])?;
    let user = abe.keygen_user("bob", &["A"])?;
    let ct_abe = abe.encrypt(r#""A""#, &z)?;
    let z2 = abe.decrypt(&user, &ct_abe)?;
    assert_eq!(z2, z.to_vec());

    // --- provider: create records
    let mut records: Vec<RecordTuple> = Vec::new();
    let mut values_flat: Vec<u32> = Vec::new();
    let mut blinds_flat: Vec<Scalar> = Vec::new();

    let n_win = 8usize;
    let params = ProtocolParams::new(n_win, 64 * 1024 * 1024)?;
    let mut seq = 100u64;
    let t0 = 1_700_000_000u64;

    for i in 0..n_win {
        let t = t0 + (i as u64);
        let nonce = nonce_from_index(i as u128)?;
        let mut vals = vec![0u32; k];
        for j in 0..k {
            vals[j] = (i as u32) * 10 + (j as u32);
            values_flat.push(vals[j]);
        }
        let mut blinds = vec![Scalar::random(&mut rng); k];
        blinds_flat.extend_from_slice(&blinds);

        // commitments over original values
        let pc_gens = bulletproofs::PedersenGens::default();
        let mut commitments = Vec::with_capacity(k);
        for j in 0..k {
            let c = pc_gens.commit(Scalar::from(vals[j] as u64), blinds[j]).compress();
            commitments.push(c);
        }

        let d = rec_digest(pid, wid, seq, t, schema, hpol, suite, &commitments);

        // plaintext = (vals[u32]*k) || (blindings[32]*k) || seq[u64] || t[u64]
        let mut pt = Vec::new();
        for v in vals.iter() { pt.extend_from_slice(&v.to_be_bytes()); }
        for r in blinds.iter() { pt.extend_from_slice(r.as_bytes()); }
        pt.extend_from_slice(&seq.to_be_bytes());
        pt.extend_from_slice(&t.to_be_bytes());

        let aad = aad_bytes(pid, wid, seq, t, schema, hpol, suite);
        let ct = aead_encrypt(&k_aead, &nonce, &aad, &pt)?;

        records.push(RecordTuple { d, seq, t, commitments, ciphertext: ct });
        seq += 1;
    }

    // build payload and header
    let (b_rec, l, h_batch) = maabe_telemetry::payload::build_payload(&records, k)?;
    let store = LocalIpfsStore::new(std::env::temp_dir().join("maabe_store"))?;
    let cid_rec = store.put_raw_block(&b_rec)?;

    // merkle root with deployment-fixed depth (derived from N_win_max)
    let depth = params.merkle_depth;
    let leaves: Vec<(u64, [u8;32])> = records.iter().enumerate().map(|(i,r)| (i as u64, r.d)).collect();
    let root = maabe_telemetry::merkle::merkle_aggregate(depth, &leaves)?;

    let seq_min = records.first().unwrap().seq;
    let seq_max = records.last().unwrap().seq;
    let t_min = records.first().unwrap().t;
    let t_max = records.last().unwrap().t;

    let serhdr = header_bytes(
        pid, wid, seq_min, seq_max, root, t_min, t_max, n_win as u64,
        schema, hpol, suite, l, h_batch, &cid_rec.to_bytes(),
    );

    // prove bulletproof window ranges (real library)
    let flat_commitments: Vec<_> = records.iter().flat_map(|r| r.commitments.clone()).collect();
    let proof_bytes = maabe_telemetry::bulletproof_win::prove_window_ranges(
        &serhdr, hpol, &policy, &flat_commitments, &values_flat, &blinds_flat,
    )?;
    let cid_proof = store.put_raw_block(&proof_bytes)?;

    // chain sim: commit/finalize
    let mut chain = maabe_telemetry::chain_sim::ChainSim::new(42, params.clone());
    chain.commit_window(PendingCommit{
        serhdr: serhdr.clone(),
        cid_rec: cid_rec.clone(),
        payload_len: l,
        payload_digest: h_batch,
        merkle_root: root,
        n_win: n_win as u64,
        schema,
        hpol,
        suite,
        wid,
        pid,
        seq_min,
        seq_max,
        t_min,
        t_max,
    })?;
    let accepted = chain.finalize_window(&store, &policy, &proof_bytes, cid_proof.clone())?;

    // derive KEK + wrap/unwrap K
    let hatt = accepted.hatt;
    let kek = derive_kek(&z, pid, wid, &hatt)?;
    let ct_k = wrap_window_key(&kek, &hpol, &hatt, &k_aead)?;
    let k_aead2 = unwrap_window_key(&kek, &hpol, &hatt, &ct_k)?;
    assert_eq!(k_aead2, k_aead);

    Ok(())
}
